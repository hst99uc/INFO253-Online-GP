# Hongyu Deng Site Design contribution

## My Appointment

My Appointment gives patients one place to review their upcoming consultation and manage it without calling the clinic. The main card groups the doctor, date, time, consultation type and NZ$45 example fee. A separate preparation panel lists what patients should check before joining. Past appointments sit below the active booking so they do not compete with the current task.

Change Date & Time opens a panel within the appointment card. The patient selects a sample available date and time, then chooses Confirm New Appointment. Keep Current Appointment closes the panel without changing the booking, and Escape provides another exit. The updated details and confirmation message show the result. Cancel Appointment opens a confirmation dialog containing the doctor, date and example cancellation policy. Keep Appointment receives initial focus. Confirming cancellation changes the status and disables actions that no longer apply.

My Profile links directly to the profile page. Book New Appointment opens Find GP. The group header remains in place, and the existing shared stylesheet controls the appearance. The layout stacks its content on a narrow screen. The prototype does not connect to a payment service, appointment database or live video room. Its fee, availability and two-hour cancellation policy are sample content requiring business confirmation.

![My Appointment proposed integrated version](my-appointment-desktop.png)

Figure My Appointment after the integration repair in PR 1. PR 1 has been merged into main (merge commit 21553ae). The screenshot was captured from the tested branch; the merged website files were verified to be identical to that branch.

## My Profile

My Profile separates personal information from healthcare preferences. Each section has its own edit and save controls, so a patient can change one group of fields without changing the other. Appointment reminders and email notifications appear in their own section on the same page. A note explains that these switches take effect immediately.

Edit Personal Information reveals the editable contact fields. Legal name and date of birth remain read-only; the page explains that changing identity details requires support. Emergency contact name and telephone number are separate fields. Invalid telephone input is rejected with a text message, and the patient remains in edit mode. Save Personal Information updates the displayed contact details without changing the identity display. Discard Changes restores the last saved values. Healthcare preferences use a pharmacy drop-down and a separate Save Preferences control.

The sidebar links to My Appointment, Prescriptions and the existing Messages view. My Profile is marked as the current section. The content becomes a single-column layout on smaller screens. The patient and pharmacy details are examples. Changes are held only in the page session; refreshing resets them. Authentication, server-side validation and a working change-password service are not implemented in this prototype.

![My Profile proposed integrated version](my-profile-desktop.png)

Figure My Profile after the integration repair in PR 1. The tested branch and the merged main website files were verified to be identical.

