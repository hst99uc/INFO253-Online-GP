# Site map reconciliation

Prepared by Hongyu Deng on 12 October 2026. This record updates the earlier V1 hierarchy against the repository inspected for PR 1. It is not a final sign-off of the whole website.

## Public pages and views

| Page or view | Current destination | Representation |
| --- | --- | --- |
| Home | home.html | HTML page |
| Sign In | login.html | HTML page |
| Services | services.html | HTML page |
| Find GP | find-gp.html | HTML page |
| How It Works | how-it-works.html | HTML page and embedded view |
| FAQ | faq.html | HTML page |
| Contact Us | how-it-works.html#contact | Embedded view |
| Doctor details and time selection | Within Find GP | Modal or embedded interaction, not a separate Doctor Profile HTML file |

## Patient account pages and views

| Page or view | Current destination | Parent or task group |
| --- | --- | --- |
| My Appointment | my-appointment.html | Patient account |
| My Profile | my-profile.html | Patient account |
| Message | how-it-works.html#messages | Patient account, embedded view |
| Prescriptions | prescriptions.html | Patient account |
| Prescription request | prescription-request.html | Prescriptions |
| Prescription review | prescription-review.html | Prescription request |
| Prescription confirmation | prescription-confirmation.html | Prescription review |
| Medical Certificates | medical-certificates.html | Patient account |
| Certificate request | certificate-request.html | Medical Certificates |
| Certificate review | certificate-review.html | Certificate request |
| Certificate confirmation | certificate-confirmation.html | Certificate review |

## Hierarchy source for the diagram

```mermaid
flowchart TD
    SITE[Online GP]
    SITE --> PUBLIC[Public information]
    SITE --> ACCOUNT[Patient account]
    PUBLIC --> H[Home]
    PUBLIC --> SI[Sign In]
    PUBLIC --> S[Services]
    PUBLIC --> FG[Find GP]
    PUBLIC --> HW[How It Works]
    PUBLIC --> FAQ[FAQ]
    PUBLIC --> CU[Contact Us embedded view]
    FG --> GP[Doctor details and time selection modal]
    ACCOUNT --> MA[My Appointment]
    ACCOUNT --> MP[My Profile]
    ACCOUNT --> MSG[Message embedded view]
    ACCOUNT --> RX[Prescriptions]
    RX --> RQ[Prescription request]
    RQ --> RR[Prescription review]
    RR --> RC[Prescription confirmation]
    ACCOUNT --> MC[Medical Certificates]
    MC --> CQ[Certificate request]
    CQ --> CR[Certificate review]
    CR --> CC[Certificate confirmation]
    MA -. Book New Appointment .-> FG
    MA -. Account link .-> MP
    MP -. Sidebar links .-> MA
    MP -. Sidebar links .-> RX
    MP -. Sidebar links .-> MSG
```

Public information and Patient account are organisational groups, not extra pages. The diagram describes the intended information hierarchy and does not assert that authentication or every cross-site link is implemented. Dashed edges describe the connections added or preserved in Hongyu's two-page patch.

## Decisions still required before the final diagram

- The current Find GP flow points to book.html, which is absent. Do not describe Book Appointment or Booking Confirmation as available pages until their destinations are supplied.
- The report describes a clinician GP Appointments view. Its final route and relationship to the rest of the website still need confirmation; it cannot be invented from the patient My Appointment page.
- index.html currently serves a patient-services overview and default.html is a template. Ask the group whether the overview is an intended final page. Do not count templates as page prototypes.
- Include Contact Us and Message as views rather than silently omitting them because they share a file.
- The course's 15 to 20 planned-page requirement must be assessed using the agreed logical pages and screenshots, not raw file counts. This inventory is not proof that the requirement has been met.

Hongyu can prepare the hierarchy and inventory now. The final diagram still requires the agreed page set and the final navigation destinations, not merely permission to merge PR 1.
