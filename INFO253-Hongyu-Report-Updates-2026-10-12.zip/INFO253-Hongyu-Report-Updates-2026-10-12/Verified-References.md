# Verified references for Hongyu's self assessment

## References to insert

Nielsen, J. (1994, April 24). *10 usability heuristics for user interface design*. Nielsen Norman Group. https://www.nngroup.com/articles/ten-usability-heuristics/

World Wide Web Consortium. (2024, December 12). *Web Content Accessibility Guidelines (WCAG) 2.2*. https://www.w3.org/TR/2024/REC-WCAG22-20241212/

## Evidence of authenticity and relevance

The Nielsen Norman Group page identifies Jakob Nielsen as author and 24 April 1994 as its original publication date. It records 30 January 2024 as the last review date. The sections User Control and Freedom and Error Prevention support Hongyu's discussion of leaving rescheduling safely and avoiding mistaken actions. This source is not evidence that the example two-hour cancellation rule is a real clinic policy.

The W3C page identifies itself as a W3C Recommendation dated 12 December 2024. It is a fixed, dated edition rather than a moving latest-version link. Success Criterion 3.3.1 covers identifying automatically detected input errors in text. Success Criterion 3.3.2 covers labels or instructions. These support discussion of the phone input and labelled controls, not a claim of full WCAG conformance.

## Citation matching

Use (Nielsen, 1994) for the official article's original publication year. The updated Word copy changes only this year in Hongyu's existing self-assessment. No reflection sentences are rewritten.

Use (W3C, 2024) after introducing the organisation as World Wide Web Consortium (W3C), or use (World Wide Web Consortium, 2024) if its abbreviation has not been introduced in the report. The W3C abbreviation already appears in the supplied group document.

The same verified source can support several team members. Include each identical reference once in the final reference list. Do not substitute a different article merely to avoid sharing a source.

