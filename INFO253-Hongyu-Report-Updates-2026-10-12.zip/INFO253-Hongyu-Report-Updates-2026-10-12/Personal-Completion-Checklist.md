# Hongyu Deng personal completion checklist

## Completed in this update

- Merged PR 1 into the group repository's main branch (merge commit 21553ae). Only My Appointment and My Profile were changed. The merged files were verified to be identical to the technically tested branch.
- Confirmed that the individual self-assessment is present under Hongyu in f3. Its wording and structure are preserved.
- Added the two references used in that self-assessment to a separate updated copy of f3.
- Changed only the Nielsen citation year in Hongyu's paragraph from 2024 to 1994 to match the official article's original publication date. The page was last reviewed on 30 January 2024.
- Prepared current Site Design text and two screenshots for My Appointment and My Profile.
- Prepared a site-map reconciliation record using the current repository structure, identifying actual pages, embedded views and unavailable booking destinations.

## Placement in the report

Use the updated f3 copy for the reference corrections, or copy only the two new references and the single citation-year correction into the live group document. Do not replace a newer shared document with this local copy if teammates have edited it since f3 was downloaded.

Place the two page descriptions and matching screenshots under Site Design if those materials are not already in the live group report. The Home page palette, fonts and graphics belong to the shared site presentation; Hongyu does not need to author another member's pages.

Use the site-map reconciliation record to update the existing diagram. Do not label missing booking pages or a clinician view as implemented. Distinguish embedded views from separate HTML pages. A list of filenames is not a substitute for the course-required hierarchy diagram.

## Remaining checks that cannot be signed off yet

- Check the final shared report to confirm these materials were inserted once, with the correct captions and reference formatting.
- Verify the final site-map diagram against the final agreed page set, including the status of booking confirmation and the clinician view.
- Recheck Hongyu's two pages in the merged website and replace screenshots only if the final appearance differs.
- If the report claims a human follow-up test of the final version, obtain and record a real test. Technical browser checks are not human participant evidence.

## Scope of the course requirements

The course brief requires every team member to write a self-assessment. The eight-page maximum applies to the complete Self-evaluation section, not to each person. It does not specify an individual 300 to 350 word requirement.

The brief requires 15 to 20 planned page prototypes across the group and a site-map hierarchy diagram. Evidence of iterations concerns two selected pages across the group; Hongyu is not required to duplicate Theo's assigned iteration chapter. Hongyu's own existing test records should remain available as supporting evidence.

## Sources checked

Course brief: 2026groupproject (2).docx, The final report.
Current supplied report: f3Group Project Part 2 - INFO253.docx.
Website comparison: https://github.com/hst99uc/INFO253-Online-GP/pull/1

Only Hongyu's references were added. Existing reference entries used by other members were not rewritten. The older Nielsen 2016 entry remains for the group editor to check against the other members' citations.

